package project;
import java.sql.*;
import java.util.Scanner;

public class CustomerServiceRequestSystem1 {
    private static final String URL = "jdbc:mysql://localhost:3306/service_db";
    private static final String USER = "root";
    private static final String PASSWORD = "9492@9492";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\nCustomer Service Request System");
                System.out.println("1. Create Service Request");
                System.out.println("2. View Request Status");
                System.out.println("3. View All Requests (Vendor)");
                System.out.println("4. Provide Suggestion (Vendor)");
                System.out.println("5. Update Request Status (Vendor)");
                System.out.println("6. Exit");
                System.out.print("Enter choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        createRequest(scanner);
                        break;
                    case 2:
                        viewRequestStatus(scanner);
                        break;
                    case 3:
                        viewAllRequests();
                        break;
                    case 4:
                        provideSuggestion(scanner);
                        break;
                    case 5:
                        updateRequestStatus(scanner);
                        break;
                    case 6:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }
        }
    }

    private static void createRequest(Scanner scanner) {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter request description: ");
        String description = scanner.nextLine();

        String sql = "INSERT INTO service_requests (client_name, description, status, suggestion) VALUES (?, ?, 'Active', '')";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                System.out.println("Request created successfully. Request ID: " + rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewRequestStatus(Scanner scanner) {
        System.out.print("Enter your request ID: ");
        int requestId = scanner.nextInt();

        String sql = "SELECT status, suggestion FROM service_requests WHERE request_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Current Status: " + rs.getString("status"));
                System.out.println("Vendor Suggestion: " + rs.getString("suggestion"));
            } else {
                System.out.println("Request ID not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllRequests() {
        String sql = "SELECT * FROM service_requests";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("request_id") + ", Name: " + rs.getString("client_name") +
                        ", Description: " + rs.getString("description") + ", Status: " + rs.getString("status") +
                        ", Suggestion: " + rs.getString("suggestion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void provideSuggestion(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter your suggestion: ");
        String suggestion = scanner.nextLine();

        String sql = "UPDATE service_requests SET suggestion = ? WHERE request_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, suggestion);
            stmt.setInt(2, requestId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Suggestion added successfully.");
            } else {
                System.out.println("Request ID not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateRequestStatus(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new status (Active/Pending/Resolved): ");
        String status = scanner.nextLine();

        String sql = "UPDATE service_requests SET status = ? WHERE request_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, requestId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Request updated successfully.");
            } else {
                System.out.println("Request ID not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

